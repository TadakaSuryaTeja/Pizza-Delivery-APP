# Creating a SuperUser

python manage.py createsuperuser
